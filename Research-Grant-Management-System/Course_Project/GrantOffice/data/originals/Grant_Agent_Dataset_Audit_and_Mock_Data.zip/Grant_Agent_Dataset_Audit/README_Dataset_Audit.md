# Grant Agent — Dataset Audit and Mock Data Pack
Generated: 2026-10-27

## Executive finding
The uploaded files are useful institutional-history and publication-profile datasets. They do **not** provide a complete live funding-opportunity database. They generally lack original official call URLs/PDF locators, current application deadlines/status, call-specific eligibility rules, allowable-cost rules, and source freshness metadata.

Use two data layers:
1. **Institutional profile/history** — real past funded projects, past applications, PI/department history, and publication metadata.
2. **Funding opportunities** — live official calls retrieved through the Grant Connector; each record must carry source provenance, deadline, eligibility evidence and current verification status.

Never turn a historical sanction date into a current application deadline. Never interpret a grant being awarded in the past as proof that a new call is open or that the same PI is currently eligible.

## Audit of uploaded files
- `External_Funded_Project_List(1).xlsx`: 4 sheets. Its `Details_2022-23-24-25` sheet has 19 project entries across three annual sections. `Sheet1` contains a partial historical list (~16 rows, some likely duplicated/incomplete). `Applied-Sanctoon_R1/R2` are department-level summary tables, not live calls.
- `Applied_Sanctioned_Grants_2025-26-Format(1).xlsx`: two applied records; the sanctioned section is marked `NIL`. A date of 14/08/2026 is outside the stated July 2025–July 2026 cycle. One applied amount is text (`1.5L`) despite the INR-lakhs column.
- `Sanctioned_External Funded Projects 2013-2024 updated(1).doc`: historical sanctioned project list, serials 1–65, with titles, investigators, agencies, amounts and completion notes; not active calls.
- `2022-23 Aug 22- July 2023 (1)(2).xlsx`: summary states 91 publications (76 conferences, 11 journals, 4 book chapters). Supporting tabs overlap.
- `2023-24 Aug 2023- July 2024 Correct(2).xlsx`: `MASTER` contains 106 publication-title rows, with overlapping category tabs.
- `2024-25 Aug 2024- July 2025(2).xlsx`: `Master Data` contains 100 publication-title rows; other tabs overlap.
- `2025-26 Aug 2025 - July 2026(2).xlsx`: master sheet has 233 publication-title rows; NBA Students tab overlaps.

## What the real uploaded data contributes
`derived_profile/institutional_research_profile.json` contains 24 deduplicated health/medical/cardiovascular-related publication metadata entries extracted from the uploaded publication sheets. Examples include:
- Text-based prediction of heart disease using machine learning (2022-23)
- Heart sound classification using deep-learning neural networks (2023-24)
- Prediction of cardiac severity from ECG images using deep learning (2023-24)
- MedBot: LLM-powered assistant for heart disease (2024-25)
- Heart-disease prediction with ensemble learning and behavioral patterns (2025-26)
- Cardiac vessel segmentation, hemodynamic profiling, and arrhythmia-classification titles (2025-26)

These metadata can support an institutional expertise/relevance profile. They are not proof of funding, not current calls, and not substitutes for reading/citing the underlying papers.

## Mock data files
All records under `mock_data/` are **synthetic**; all source URLs use `example.invalid`; `verified` is always false. They are intended to test filtering, missing-field handling, expiration, research-area mismatch, and human-review branches.

- `funding_calls_mock.json`: four synthetic funding-call records.
- `funding_call_candidates_mock.json`: three synthetic candidates including pending review, apparent statuses with unverified source, and missing evidence.
- `funding_call_guidelines_mock.json`: two synthetic guideline examples.
- `mock_data_scenarios.csv`: expected behavior per fixture.

**Do not replace `data/funding_calls.json` or `data/funding_call_candidates.json` with these fixtures.** They should not make the production project pass validation. The `verified` flag remains false because no official source was consulted for these mock items.

## Missing data to obtain for production
1. Current funding calls and official pages/PDFs from agencies.
2. Original call identifiers, issue/publication dates, application deadlines and timezone, deadline status, source URLs and exact source locators.
3. Call-specific eligibility and allowed-cost/budget rules from official guidelines.
4. Official institutional budget/personnel cost rules and policy versions (check the existing project data folder; not all were supplied in this upload).
5. Rechecking/source freshness metadata and an auditable verification method.
6. Final award/application outcome fields for institutional history.

## Recommended architecture
- Keep historic grants and applications separate from open calls.
- Let the Grant Connector retrieve current calls from configured official sources.
- Normalize amount units explicitly (`INR`, `INR lakh`, etc.) before calculations.
- Treat a retrieved page as source material, not as proof that a call matches or that a researcher is eligible.
- Keep `eligibility_status` and `novelty_status` pending until reviewed; a real URL alone must not clear those gates.
- Keep mock fixtures in `data/mock/` (or a dedicated test fixtures directory), never in production data paths.

## Notes about counts
Publication sheets have overlapping master/student/faculty/M.Tech/NBA tabs. The row counts in the audit are per named master/summary view; do not add all sheet counts together. Deduplicate publication metadata by `PUB ID` before creating institution-level counts.
